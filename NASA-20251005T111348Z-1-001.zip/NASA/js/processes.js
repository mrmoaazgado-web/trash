document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('processSearchInput');
    const typeFilter = document.getElementById('processTypeFilter');
    const processesGrid = document.getElementById('processesGrid');

    let allProcessesData = [];

    const generateProcessCardHTML = (proc) => {
        // Safely access nested details properties
        const trl = proc.details && proc.details.trl ? proc.details.trl : 'N/A';
        const power = proc.details && proc.details.power ? proc.details.power : 'N/A';
        const efficiency = proc.details && proc.details.efficiency ? proc.details.efficiency : 'N/A';

        const inputsList = proc.inputs && proc.inputs.length > 0 ? proc.inputs.map(i => `<li>${i}</li>`).join('') : '<li>None</li>';
        const outputsList = proc.outputs && proc.outputs.length > 0 ? proc.outputs.map(o => `<li>${o}</li>`).join('') : '<li>None</li>';

        return `
            <div class="card-header">
                <h3 class="card-title">${proc.name}</h3>
                <div class="process-type-badge">${proc.type}</div>
            </div>
            <p class="card-description">${proc.description}</p>
            <div class="card-stats process-parameters">
                <div class="stat-item"><div class="stat-label">TRL</div><div class="stat-value">${trl}</div></div>
                <div class="stat-item"><div class="stat-label">Power</div><div class="stat-value">${power}</div></div>
                <div class="stat-item"><div class="stat-label">Efficiency</div><div class="stat-value">${efficiency}</div></div>
            </div>
            <div class="io-flow-container">
                <div class="io-column"><h4><i class="fas fa-arrow-down"></i> Inputs</h4><ul>${inputsList}</ul></div>
                <div class="io-column"><h4><i class="fas fa-arrow-up"></i> Outputs</h4><ul>${outputsList}</ul></div>
            </div>`;
    };

    const renderProcesses = () => {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedType = typeFilter.value;
        
        const filteredData = allProcessesData.filter(proc =>
            (selectedType === 'all' || proc.type === selectedType) &&
            proc.name.toLowerCase().includes(searchTerm)
        );

        processesGrid.innerHTML = '';
        if (filteredData.length === 0) {
            processesGrid.innerHTML = `<p class="no-results-message">No processes found.</p>`;
            return;
        }

        filteredData.forEach(proc => {
            const card = document.createElement('div');
            card.className = 'result-card';
            card.innerHTML = generateProcessCardHTML(proc);
            processesGrid.appendChild(card);
        });
    };

    const highlightProcessFromURL = () => {
        const urlParams = new URLSearchParams(window.location.search);
        const processToHighlight = urlParams.get('highlight');
        if (!processToHighlight) return;

        // Use a slight delay to ensure all cards are rendered
        setTimeout(() => {
            const allCards = document.querySelectorAll('.result-card');
            for (const card of allCards) {
                const cardTitle = card.querySelector('.card-title').textContent;
                if (cardTitle === processToHighlight) {
                    card.classList.add('highlighted');
                    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    break;
                }
            }
        }, 100); // 100ms delay
    };

    fetch('http://127.0.0.1:5000/api/processes')
        .then(response => response.json())
        .then(data => {
            allProcessesData = data;
            renderProcesses();
            highlightProcessFromURL(); // This will highlight the card after rendering
        })
        .catch(error => {
            console.error('Error fetching processes:', error);
            processesGrid.innerHTML = `<p class="no-results-message">Failed to load processes.</p>`;
        });

    searchInput.addEventListener('input', renderProcesses);
    typeFilter.addEventListener('change', renderProcesses);
});