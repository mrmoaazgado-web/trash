document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('processSearchInput');
    const typeFilter = document.getElementById('processTypeFilter');
    const processesGrid = document.getElementById('processesGrid');
    const modal = document.getElementById('processDetailModal');
    const modalContent = document.getElementById('modalContentContainer');
    const closeModalBtn = document.getElementById('closeProcessModalBtn');

    let allProcessesData = [];

    const generateProcessCardHTML = (proc) => { /* ... (Function remains the same) ... */ };
    const renderProcesses = () => { /* ... (Function remains the same) ... */ };

    // --- New functions to handle the modal ---
    const openProcessModal = (processName) => {
        fetch(`http://127.0.0.1:5000/api/process/${encodeURIComponent(processName)}`)
            .then(response => {
                if (!response.ok) throw new Error('Process not found');
                return response.json();
            })
            .then(proc => {
                modalContent.innerHTML = generateProcessCardHTML(proc); // Reuse the card HTML generator
                modal.style.display = 'flex';
            })
            .catch(error => console.error('Error fetching single process:', error));
    };

    const closeModal = () => {
        modal.style.display = 'none';
        // Clear the highlight parameter from the URL without reloading
        if (history.pushState) {
            const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
            window.history.pushState({path: newUrl}, '', newUrl);
        }
    };

    // Fetch all processes to display the main grid
    fetch('http://127.0.0.1:5000/api/processes')
        .then(response => response.json())
        .then(data => {
            allProcessesData = data;
            renderProcesses();
            
            // Check if URL has a highlight parameter to open the modal immediately
            const urlParams = new URLSearchParams(window.location.search);
            const processToOpen = urlParams.get('highlight');
            if (processToOpen) {
                openProcessModal(processToOpen);
            }
        })
        .catch(error => console.error('Error fetching processes:', error));

    // Event Listeners
    searchInput.addEventListener('input', renderProcesses);
    typeFilter.addEventListener('change', renderProcesses);
    closeModalBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            closeModal();
        }
    });
});