document.addEventListener('DOMContentLoaded', () => {
    
    // --- 1. تطبيق حجم الخط المحفوظ ---
    // يقرأ حجم الخط المفضل للمستخدم من الذاكرة ويطبقه على الصفحة بأكملها.
    const savedSize = localStorage.getItem('app_font_size') || 'medium';
    let fontSize = '16px'; // الحجم الافتراضي
    if (savedSize === 'small') {
        fontSize = '14px';
    } else if (savedSize === 'large') {
        fontSize = '18px';
    }
    document.documentElement.style.fontSize = fontSize;
    
    // --- 2. منطق تغيير الثيم (Light/Dark Mode) ---
    // يدير زر التبديل بين الوضع الفاتح والداكن ويحفظ اختيار المستخدم.
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;
    const currentTheme = localStorage.getItem('theme') || 'dark';
    if (currentTheme === 'light') {
        body.classList.add('light-mode');
        updateThemeButton(true);
    }
    themeToggle.addEventListener('click', () => {
        body.classList.toggle('light-mode');
        const isLight = body.classList.contains('light-mode');
        localStorage.setItem('theme', isLight ? 'light' : 'dark');
        updateThemeButton(isLight);
    });

    function updateThemeButton(isLight) {
        const icon = themeToggle.querySelector('i');
        const text = themeToggle.querySelector('span');
        if (isLight) {
            icon.className = 'fas fa-sun';
            text.textContent = 'Light Mode';
        } else {
            icon.className = 'fas fa-moon';
            text.textContent = 'Dark Mode';
        }
    }

    // --- 3. منطق القائمة الجانبية في وضع الموبايل ---
    // مسؤول عن إظهار وإخفاء القائمة الجانبية عند عرض الموقع على شاشة صغيرة.
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebar = document.getElementById('sidebar');
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            mobileMenuToggle.querySelector('i').className = sidebar.classList.contains('open') ? 'fas fa-times' : 'fas fa-bars';
        });
    }

    // --- 4. منطق تظليل الرابط النشط ---
    // يحدد الصفحة الحالية التي يزورها المستخدم ويضيف علامة "active" للرابط الخاص بها في القائمة الجانبية.
    const currentPageFile = window.location.pathname.split('/').pop();
    const navLinks = document.querySelectorAll('.sidebar-nav .nav-link');

    navLinks.forEach(link => {
        const linkFile = link.getAttribute('href');
        if (linkFile === currentPageFile || (currentPageFile === '' && linkFile === 'index.html')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
});