document.addEventListener('DOMContentLoaded', () => {
    // 1. Get references to all necessary HTML elements
    const searchInput = document.getElementById('itemSearchInput');
    const typeFilter = document.getElementById('typeFilter');
    const sourceFilter = document.getElementById('sourceFilter');
    const inventoryGrid = document.getElementById('inventoryGrid');
    
    // Modal elements
    const addItemModal = document.getElementById('addItemModal');
    const openAddItemModalBtn = document.getElementById('openAddItemModalBtn');
    const closeAddItemModalBtn = document.getElementById('closeAddItemModalBtn');
    const addItemForm = document.getElementById('addItemForm');
    const cancelAddItemBtn = document.getElementById('cancelAddItemBtn');

    let allInventoryData = [];

    // 2. Main function to fetch and render the inventory
    const fetchAndRender = () => {
        fetch('http://127.0.0.1:5000/api/inventory')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                allInventoryData = data.sort((a, b) => a.name.localeCompare(b.name));
                renderInventory();
            })
            .catch(error => {
                console.error('Error fetching inventory:', error);
                inventoryGrid.innerHTML = `<p class="no-results-message">Failed to load inventory from the server. Please ensure the backend server is running and check the console for errors.</p>`;
            });
    };

    // 3. Function to render the inventory based on current filters
    const renderInventory = () => {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedType = typeFilter.value;
        const selectedSource = sourceFilter.value;

        const filteredData = allInventoryData.filter(item =>
            (selectedType === 'all' || item.type === selectedType) &&
            (selectedSource === 'all' || item.source === selectedSource) &&
            (item.name.toLowerCase().includes(searchTerm))
        );

        inventoryGrid.innerHTML = '';
        if (filteredData.length === 0) {
            inventoryGrid.innerHTML = `<p class="no-results-message">No items found matching your criteria.</p>`;
            return;
        }

        filteredData.forEach(item => {
            const card = document.createElement('div');
            card.className = 'result-card inventory-item';
            card.dataset.itemName = item.name;
            card.innerHTML = generateCardHTML(item);
            inventoryGrid.appendChild(card);
        });
    };

    // 4. Function to generate HTML for a single item card
    const generateCardHTML = (item) => {
        const quantityColor = item.quantity > 0 ? 'var(--success-color, #4CAF50)' : '#d32f2f';
        let detailsHTML = '';
        if (item.details) {
            for (const [key, value] of Object.entries(item.details)) {
                const formattedKey = key.charAt(0).toUpperCase() + key.slice(1);
                detailsHTML += `<div class="card-detail"><strong>${formattedKey}:</strong> <span>${value}</span></div>`;
            }
        }
        return `
            <button class="delete-item-btn" data-id="${item.id}" title="Delete Item"><i class="fas fa-trash-alt"></i></button>
            <div class="card-header"> <h3 class="card-title item-name"><span>${item.name}</span></h3> <div class="card-source-badge">${item.source || 'N/A'}</div> </div>
            <div class="card-body-section"> <div class="inventory-stat" style="background-color: rgba(0,0,0,0.2); padding: 0.8rem; border-radius: 6px;"> <div class="stat-label">Current Stock</div> <div class="stat-value" style="color: ${quantityColor}; font-size: 1.5rem;">${item.quantity} ${item.unit}</div> </div> </div>
            <div class="card-body-section"> <p class="card-description">${item.description || 'No description available.'}</p> </div>
            <div class="card-body-section"> ${detailsHTML} </div>`;
    };

    // 5. Modal and Form Handling
    const closeModal = () => {
        addItemForm.reset();
        addItemModal.style.display = 'none';
    };
    openAddItemModalBtn.addEventListener('click', () => { addItemModal.style.display = 'flex'; });
    closeAddItemModalBtn.addEventListener('click', closeModal);
    cancelAddItemBtn.addEventListener('click', closeModal);
    window.addEventListener('click', (event) => { if (event.target == addItemModal) { closeModal(); } });

    addItemForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const newItemData = {
            name: document.getElementById('itemName').value,
            quantity: parseFloat(document.getElementById('itemQuantity').value),
            unit: document.getElementById('itemUnit').value,
            type: document.getElementById('itemType').value,
            source: document.getElementById('itemSource').value,
            description: document.getElementById('itemDescription').value,
            details: {}
        };
        fetch('http://127.0.0.1:5000/api/inventory', {
            method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(newItemData),
        })
        .then(response => {
            if (!response.ok) { return response.json().then(err => { throw new Error(err.error || 'Unknown error occurred') }); }
            return response.json();
        })
        .then(addedItem => {
            // تحديث الواجهة مباشرة بدون إعادة تحميل
            allInventoryData.push(addedItem);
            allInventoryData.sort((a, b) => a.name.localeCompare(b.name)); // Re-sort
            renderInventory();
            closeModal();
        })
        .catch((error) => {
            console.error('Error:', error);
            alert(`Failed to add item: ${error.message}`);
        });
    });
    
    // 6. Grid Click Handling (Delete and Show Processes)
    inventoryGrid.addEventListener('click', (event) => {
        const deleteButton = event.target.closest('.delete-item-btn');
        const clickedCard = event.target.closest('.inventory-item');

        if (deleteButton) {
            event.stopPropagation();
            const itemId = deleteButton.dataset.id;
            const itemName = clickedCard.dataset.itemName;
            if (confirm(`Are you sure you want to delete "${itemName}"? This action cannot be undone.`)) {
                deleteItem(itemId);
            }
        } else if (clickedCard) {
            const itemName = clickedCard.dataset.itemName;
            if (itemName) { findProcessesForItem(itemName); }
        }
    });

    const deleteItem = (itemId) => {
        fetch(`http://127.0.0.1:5000/api/inventory/${itemId}`, { method: 'DELETE' })
        .then(response => {
            if (!response.ok) { return response.json().then(err => { throw new Error(err.error || 'Failed to delete') }); }
            return response.json();
        })
        .then(data => {
            console.log(data.message);
            // تحديث الواجهة مباشرة بدون إعادة تحميل
            allInventoryData = allInventoryData.filter(item => item.id != itemId);
            renderInventory();
        })
        .catch(error => {
            console.error('Error:', error);
            alert(`Failed to delete item: ${error.message}`);
        });
    };

    // 7. Processes Modal Handling (no changes here)
    const findProcessesForItem = (name) => {
        fetch(`http://127.0.0.1:5000/api/processes-for-item/${encodeURIComponent(name)}`)
            .then(response => { if (!response.ok) { throw new Error('Network response was not ok'); } return response.json(); })
            .then(processes => { showProcessesModal(name, processes); })
            .catch(error => { alert('Failed to fetch related processes.'); });
    };
    const showProcessesModal = (itemName, processes) => {
        const existingModal = document.getElementById('processesModal');
        if (existingModal) { existingModal.remove(); }
        const modal = document.createElement('div');
        modal.id = 'processesModal';
        modal.style.cssText = `position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 1000;`;
        let listHtml = '';
        if (processes.length > 0) { listHtml = processes.map(proc => `<li style="margin-bottom: 10px; padding: 10px; border: 1px solid #444; border-radius: 5px;"> <strong>${proc.name}</strong> <p style="margin: 5px 0 0; font-size: 0.9em; color: #ccc;">Produces: ${proc.outputs.join(', ')}</p> <a href="processes.html?highlight=${encodeURIComponent(proc.name)}" style="color: var(--primary-color); text-decoration: none;">View Process Details</a> </li>`).join(''); }
        else { listHtml = `<li>No specific recycling processes found that use this item as an input.</li>`; }
        modal.innerHTML = ` <div class="modal-content" style="background: #2a2d3b; padding: 25px; border-radius: 8px; width: 90%; max-width: 500px; color: #fff;"> <h3 style="margin-top: 0;">Processes Using: ${itemName}</h3> <ul style="list-style: none; padding: 0; max-height: 300px; overflow-y: auto;">${listHtml}</ul> <button id="closeModalBtn" style="margin-top: 20px; padding: 10px 15px; background: var(--primary-color); color: #fff; border: none; border-radius: 5px; cursor: pointer;">Close</button> </div> `;
        document.body.appendChild(modal);
        document.getElementById('closeModalBtn').addEventListener('click', () => modal.remove());
        modal.addEventListener('click', (e) => { if (e.target.id === 'processesModal') { modal.remove(); } });
    };

    // 8. Initial Setup
    searchInput.addEventListener('input', renderInventory);
    typeFilter.addEventListener('change', renderInventory);
    sourceFilter.addEventListener('change', renderInventory);
    
    fetchAndRender(); // Initial data load
});