document.addEventListener('DOMContentLoaded', () => {
    // --- ELEMENTS ---
    const totalItemsStat = document.getElementById('totalItemsStat');
    const totalProcessesStat = document.getElementById('totalProcessesStat');
    const lowStockStat = document.getElementById('lowStockStat');
    const totalMassStat = document.getElementById('totalMassStat');

    const byTypeCtx = document.getElementById('inventoryByTypeChart').getContext('2d');
    const bySourceCtx = document.getElementById('inventoryBySourceChart').getContext('2d');
    
    const lowStockList = document.getElementById('lowStockList');
    const recentUpdatesList = document.getElementById('recentUpdatesList');

    let byTypeChart = null;
    let bySourceChart = null;

    const fetchData = () => {
        Promise.all([
            fetch('http://127.0.0.1:5000/api/inventory').then(res => res.json()),
            fetch('http://127.0.0.1:5000/api/processes').then(res => res.json()),
            fetch('http://127.0.0.1:5000/api/inventory/low-stock').then(res => res.json())
        ])
        .then(([inventory, processes, lowStock]) => {
            updateStatCards(inventory, processes, lowStock);
            createOrUpdateCharts(inventory);
            populateLists(inventory, lowStock);
        })
        .catch(error => {
            console.error("Failed to load dashboard data:", error);
        });
    };

    const updateStatCards = (inventory, processes, lowStock) => {
        totalItemsStat.textContent = inventory.length;
        totalProcessesStat.textContent = processes.length;
        lowStockStat.textContent = lowStock.length;
        const totalMass = inventory.reduce((sum, item) => {
            if (item.unit.toLowerCase() === 'kg' || item.unit.toLowerCase() === 'liters') {
                return sum + parseFloat(item.quantity);
            }
            return sum;
        }, 0);
        totalMassStat.textContent = `${totalMass.toFixed(1)} kg`;
    };
    
    const createOrUpdateCharts = (inventory) => {
        const typeCounts = inventory.reduce((acc, item) => { acc[item.type] = (acc[item.type] || 0) + 1; return acc; }, {});
        const sourceCounts = inventory.reduce((acc, item) => { acc[item.source] = (acc[item.source] || 0) + 1; return acc; }, {});
        const chartColors = ['#667eea', '#764ba2', '#43e97b', '#f85149', '#ffc107', '#0dcaf0'];

        if (byTypeChart) byTypeChart.destroy();
        byTypeChart = new Chart(byTypeCtx, {
            type: 'doughnut',
            data: { labels: Object.keys(typeCounts), datasets: [{ data: Object.values(typeCounts), backgroundColor: chartColors, borderColor: '#1c1e29', borderWidth: 3 }] },
            options: { responsive: true, plugins: { legend: { position: 'top', labels: { color: '#c9d1d9' } } } }
        });

        if (bySourceChart) bySourceChart.destroy();
        bySourceChart = new Chart(bySourceCtx, {
            type: 'bar',
            data: { labels: Object.keys(sourceCounts), datasets: [{ data: Object.values(sourceCounts), backgroundColor: chartColors }] },
            options: { responsive: true, indexAxis: 'y', scales: { x: { ticks: { color: '#8b949e' } }, y: { ticks: { color: '#8b949e' } } }, plugins: { legend: { display: false } } }
        });
    };

    const populateLists = (inventory, lowStock) => {
        // --- Populate Low Stock List ---
        lowStockList.innerHTML = '';
        if (lowStock.length > 0) {
            lowStock.slice(0, 5).forEach(item => { // Show top 5
                const li = document.createElement('li');
                li.innerHTML = `
                    <a href="alerts.html">
                        <div class="item-info">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span>${item.name}</span>
                        </div>
                        <span class="item-meta">${item.quantity} ${item.unit}</span>
                    </a>`;
                lowStockList.appendChild(li);
            });
        } else {
            lowStockList.innerHTML = `<li>All stock levels are normal.</li>`;
        }

        // --- Populate Recently Updated List ---
        recentUpdatesList.innerHTML = '';
        const sortedInventory = [...inventory].sort((a, b) => new Date(b.last_updated) - new Date(a.last_updated));
        if (sortedInventory.length > 0) {
            sortedInventory.slice(0, 5).forEach(item => { // Show top 5
                const li = document.createElement('li');
                // The date will now be parsed correctly from the ISO string
                const updatedDate = new Date(item.last_updated).toLocaleDateString();
                li.innerHTML = `
                    <a href="inventory.html">
                        <div class="item-info">
                            <i class="fas fa-history"></i>
                            <span>${item.name}</span>
                        </div>
                        <span class="item-meta">${updatedDate}</span>
                    </a>`;
                recentUpdatesList.appendChild(li);
            });
        } else {
            recentUpdatesList.innerHTML = `<li>No inventory items found.</li>`;
        }
    };

    fetchData();
});