document.addEventListener('DOMContentLoaded', () => {

    // --- ELEMENTS ---
    const fontSizeSelect = document.getElementById('fontSizeSelect');
    const fontSizePreview = document.getElementById('fontSizePreview');
    const exportDataBtn = document.getElementById('exportDataBtn');
    const importDataFile = document.getElementById('importDataFile');
    const clearDataBtn = document.getElementById('clearDataBtn');
    const root = document.documentElement; // للتحكم في متغيرات CSS

    // --- FUNCTIONS ---

    /**
     * @description يغير حجم الخط الأساسي للتطبيق
     * @param {string} size - 'small', 'medium', or 'large'
     */
    const changeFontSize = (size) => {
        let fontSize;
        switch (size) {
            case 'small':
                fontSize = '14px';
                break;
            case 'large':
                fontSize = '18px';
                break;
            case 'medium':
            default:
                fontSize = '16px';
                break;
        }
        root.style.fontSize = fontSize;
        fontSizePreview.style.fontSize = fontSize; // تحديث حجم خط المعاينة
        localStorage.setItem('app_font_size', size); // حفظ الإعداد
    };

    // ==========================================================
    // ✨ تم تعديل هذه الدالة بالكامل ✨
    // ==========================================================
    /**
     * @description يجلب كل بيانات المخزن من قاعدة البيانات ويصدرها كملف JSON
     */
    const exportData = () => {
        console.log('Exporting inventory data from database...');
        
        // استدعاء الـ API لجلب بيانات المخزن
        fetch('http://127.0.0.1:5000/api/inventory')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(inventoryData => {
                // استخدام البيانات التي تم جلبها من قاعدة البيانات
                const dataStr = JSON.stringify(inventoryData, null, 2);
                const dataBlob = new Blob([dataStr], { type: 'application/json' });
                const url = URL.createObjectURL(dataBlob);
                
                const link = document.createElement('a');
                link.href = url;
                link.download = `inventory_backup_${new Date().toISOString().split('T')[0]}.json`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
                
                alert('Inventory data exported successfully!');
            })
            .catch(error => {
                console.error('Error exporting inventory data:', error);
                alert('Failed to export inventory data. Check the console for errors.');
            });
    };

    /**
     * @description يقرأ ملف JSON ويستورد البيانات إلى localStorage
     * @param {Event} event 
     */
    const importData = (event) => {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                // ملاحظة: وظيفة الاستيراد ما زالت تستورد الإعدادات.
                // لتستورد بيانات للمخزن ستحتاج لـ API endpoint مخصص.
                const importedData = JSON.parse(e.target.result);
                if (confirm('Are you sure you want to import this data? This will overwrite your current settings and scenarios.')) {
                    localStorage.setItem('isru_scenarios', JSON.stringify(importedData.isru_scenarios || []));
                    localStorage.setItem('theme', importedData.app_theme || 'dark');
                    localStorage.setItem('app_font_size', importedData.app_font_size || 'medium');
                    
                    alert('Data imported successfully! The application will now reload to apply changes.');
                    window.location.reload();
                }
            } catch (error) {
                alert('Error reading file. Please make sure it is a valid JSON backup file.');
            }
        };
        reader.readAsText(file);
    };

    /**
     * @description يحذف كل بيانات التطبيق من localStorage بعد التأكيد
     */
    const clearAllData = () => {
        if (confirm('WARNING: This will permanently delete all your saved scenarios and settings. Are you absolutely sure?')) {
            localStorage.removeItem('isru_scenarios');
            localStorage.removeItem('theme');
            localStorage.removeItem('app_font_size');
            alert('All application data has been cleared. The page will now reload.');
            window.location.reload();
        }
    };

    // --- EVENT LISTENERS ---
    fontSizeSelect.addEventListener('change', (e) => changeFontSize(e.target.value));
    exportDataBtn.addEventListener('click', exportData);
    importDataFile.addEventListener('change', importData);
    clearDataBtn.addEventListener('click', clearAllData);

    // --- INITIALIZATION ---
    const savedSize = localStorage.getItem('app_font_size') || 'medium';
    fontSizeSelect.value = savedSize;
    changeFontSize(savedSize);
});