document.addEventListener('DOMContentLoaded', () => {
    const recyclingForm = document.getElementById('recyclingForm');
    const recyclingItemsContainer = document.getElementById('recyclingItems');
    const addRecyclingItemBtn = document.getElementById('addRecyclingItemBtn');
    const itemTemplate = document.getElementById('recycling-item-template');
    const optimizeBtn = document.getElementById('openRecommendModalBtn');
    const recyclingOutputGrid = document.getElementById('recyclingOutputGrid');

    let availableRecyclables = [];

    fetch('http://127.0.0.1:5000/api/recyclable-materials')
        .then(response => response.json())
        .then(data => {
            availableRecyclables = data;
            addRecyclingItem(); // Add the first item row after fetching materials
        })
        .catch(error => console.error('Error fetching recyclable materials:', error));

    const addRecyclingItem = () => {
        const templateContent = itemTemplate.content.cloneNode(true);
        const materialSelect = templateContent.querySelector('select[name="material"]');
        
        // Add a default placeholder option
        const placeholderOption = document.createElement('option');
        placeholderOption.value = "";
        placeholderOption.textContent = "Select material...";
        placeholderOption.disabled = true;
        placeholderOption.selected = true;
        materialSelect.appendChild(placeholderOption);

        availableRecyclables.forEach(material => {
            const option = document.createElement('option');
            option.value = material.name;
            option.textContent = material.name;
            materialSelect.appendChild(option);
        });
        recyclingItemsContainer.appendChild(templateContent);
    };

    const createRecyclingCard = (data) => {
        const card = document.createElement('div');
        card.className = 'recycling-output-card';
        card.dataset.category = data.category;
        
        if (data.producing_process_name) {
            card.dataset.processName = data.producing_process_name;
            card.classList.add('clickable');
        }
        
        card.innerHTML = `
            <div class="output-icon">${data.icon}</div>
            <h3 class="output-title">${data.title}</h3>
            <p class="output-description">${data.description}</p>
            <div class="output-stats">
                <div class="output-stat"><div class="output-stat-label">Recovery Rate</div><div class="output-stat-value">${data.recovery}</div></div>
                <div class="output-stat"><div class="output-stat-label">Energy Usage</div><div class="output-stat-value">${data.energy}</div></div>
                <div class="output-stat"><div class="output-stat-label">Process Time</div><div class="output-stat-value">${data.time}</div></div>
                <div class="output-stat"><div class="output-stat-label">Quality</div><div class="output-stat-value">${data.quality}</div></div>
            </div>`;
        return card;
    };

    const handleFormSubmit = (event) => {
        event.preventDefault();
        const selectedMaterials = Array.from(recyclingItemsContainer.querySelectorAll('select[name="material"]'))
                                     .map(select => select.value).filter(Boolean);

        if (selectedMaterials.length === 0) {
            alert('Please select at least one material.');
            return;
        }

        // Show loading state
        const analyzeBtn = recyclingForm.querySelector('button[type="submit"]');
        const originalBtnHtml = analyzeBtn.innerHTML;
        analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing...';
        analyzeBtn.disabled = true;

        fetch('http://127.0.0.1:5000/api/recycling-processes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ materials: selectedMaterials })
        })
        .then(response => response.json())
        .then(allOutputs => {
            const resultsSection = document.getElementById('recyclingResults');
            document.getElementById('recyclingSummary').textContent = `Found ${allOutputs.length} potential products from ${selectedMaterials.length} material type(s).`;
            recyclingOutputGrid.innerHTML = '';
            resultsSection.classList.add('visible');

            allOutputs.forEach((output, index) => {
                setTimeout(() => {
                    recyclingOutputGrid.appendChild(createRecyclingCard(output));
                }, index * 120);
            });

            // ✨ --- هذا هو الكود الجديد للتمرير التلقائي --- ✨
            setTimeout(() => {
                resultsSection.scrollIntoView({ behavior: 'smooth' });
            }, 300); // تأخير بسيط لضمان بدء عرض البطاقات
            // ✨ ------------------------------------------ ✨
        })
        .catch(error => {
            console.error('Error fetching recycling results:', error);
            document.getElementById('recyclingSummary').textContent = 'An error occurred during analysis.';
        })
        .finally(() => {
            // Restore button state
            analyzeBtn.innerHTML = originalBtnHtml;
            analyzeBtn.disabled = false;
        });
    };

    const handleOptimizeClick = () => {
        const displayedCards = document.querySelectorAll('.recycling-output-card');
        if (displayedCards.length === 0) {
            alert("Please analyze recycling potential first.");
            return;
        }

        const outputNames = Array.from(displayedCards).map(card => card.querySelector('.output-title').textContent);

        fetch('http://127.0.0.1:5000/api/recycling-recommendation', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ outputs: outputNames })
        })
        .then(response => response.json())
        .then(data => {
            if (data.recommendation) {
                highlightCard(data.recommendation);
            }
        })
        .catch(error => console.error('Error fetching recommendation:', error));
    };
    
    const highlightCard = (recommendedName) => {
        const allCards = document.querySelectorAll('.recycling-output-card');
        allCards.forEach(card => {
            const title = card.querySelector('.output-title').textContent;
            card.classList.remove('recommended', 'dimmed');
            if (title === recommendedName) {
                card.classList.add('recommended');
            } else {
                card.classList.add('dimmed');
            }
        });
    };
    
    // --- Event Listeners ---
    addRecyclingItemBtn.addEventListener('click', addRecyclingItem);
    recyclingItemsContainer.addEventListener('click', (event) => {
        if (event.target.closest('.remove-btn') && recyclingItemsContainer.children.length > 1) {
            event.target.closest('.recycling-item').remove();
        }
    });
    recyclingForm.addEventListener('submit', handleFormSubmit);
    
    if(optimizeBtn) {
        optimizeBtn.addEventListener('click', handleOptimizeClick);
    }

    recyclingOutputGrid.addEventListener('click', (event) => {
        const clickedCard = event.target.closest('.recycling-output-card.clickable');
        if (clickedCard && clickedCard.dataset.processName) {
            const processName = clickedCard.dataset.processName;
            window.location.href = `processes.html?highlight=${encodeURIComponent(processName)}`;
        }
    });
});     