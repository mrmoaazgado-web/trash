document.addEventListener('DOMContentLoaded', () => {
    const alertsGrid = document.getElementById('alertsGrid');
    const alertCountSpan = document.getElementById('alertCount'); // ✨ تم إضافة هذا المتغير

    // This function is duplicated from inventory.js to maintain the same card style
    const generateCardHTML = (item) => {
        const quantityColor = 'var(--danger-color, #f85149)'; // Always red here
        let detailsHTML = '';
        if (item.details) {
            for (const [key, value] of Object.entries(item.details)) {
                const formattedKey = key.charAt(0).toUpperCase() + key.slice(1);
                detailsHTML += `<div class="card-detail"><strong>${formattedKey}:</strong> <span>${value}</span></div>`;
            }
        }
        // No delete button on the alerts page
        return `
            <div class="card-header"> <h3 class="card-title item-name"><span>${item.name}</span></h3> <div class="card-source-badge">${item.source || 'N/A'}</div> </div>
            <div class="card-body-section"> <div class="inventory-stat"> <div class="stat-label">Current Stock</div> <div class="stat-value" style="color: ${quantityColor}; font-size: 1.5rem;">${item.quantity} ${item.unit}</div> </div> </div>
            <div class="card-body-section"> <p class="card-description">${item.description || 'No description available.'}</p> </div>
            <div class="card-body-section"> ${detailsHTML} </div>`;
    };

    const fetchLowStockItems = () => {
        fetch('http://127.0.0.1:5000/api/inventory/low-stock')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                alertsGrid.innerHTML = '';
                
                // ✨ تم إضافة هذا الجزء لتحديث العداد ✨
                const count = data.length;
                alertCountSpan.textContent = count;

                if (count === 0) {
                    alertsGrid.innerHTML = `<p class="no-results-message">No low stock items found. All inventory levels are normal.</p>`;
                    return;
                }
                
                data.forEach(item => {
                    const card = document.createElement('div');
                    card.className = 'result-card inventory-item low-stock-alert';
                    card.innerHTML = generateCardHTML(item);
                    alertsGrid.appendChild(card);
                });
            })
            .catch(error => {
                console.error('Error fetching low stock items:', error);
                alertsGrid.innerHTML = `<p class="no-results-message">Failed to load alerts.</p>`;
                alertCountSpan.textContent = '0'; // أعد العداد إلى صفر عند حدوث خطأ
            });
    };

    // Fetch data when the page loads
    fetchLowStockItems();
});