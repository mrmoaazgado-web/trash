-- هذا الكود سيضيف البيانات الجديدة فقط، ولن يحذف البيانات الموجودة
INSERT INTO inventory (name, type, source, description, details, quantity, unit) VALUES
-- Processed Glass Products
('Thermal insulation granules', 'Processed Material', 'Recycled', 'Granules of processed glass used for thermal insulation applications.', '{"R-value": 3.5}', 0, 'kg'),
('Reflective dust layers', 'Processed Material', 'Recycled', 'Fine glass dust purposed for reflective coatings on surfaces.', '{"reflectivity": "85%"}', 0, 'kg'),
('Building panels (glass)', 'Component', 'Recycled', 'Flat panels of recycled glass for construction and glazing.', '{"size": "1x2m"}', 0, 'units'),
('PVB plastic for insulation', 'Processed Material', 'Recycled', 'Polyvinyl butyral plastic layer recovered from laminated glass, used for insulation.', '{"form": "Sheet"}', 25.5, 'kg'),
('Glass Wool Insulation', 'Processed Material', 'Recycled', 'Fibrous thermal insulation material made from glass wool.', NULL, 0, 'square meters'),
('Foam Glass Blocks/Panels', 'Component', 'Recycled', 'Lightweight and rigid insulation panels made from foam glass.', NULL, 0, 'square meters'),
('Protective Glass Panels', 'Component', 'Recycled', 'Durable glass panels for solar arrays and radiation-shielded windows.', NULL, 0, 'square meters'),
('Glass Fibers (Long/Short)', 'Processed Material', 'Recycled', 'Glass fibers used as reinforcement in composite materials.', NULL, 0, 'kilograms'),
('Glasscrete Building Blocks', 'Component', 'Recycled', 'Construction blocks made from a composite of glass and other binders.', NULL, 0, 'units'),
('Decorative Glass Tiles', 'Component', 'Recycled', 'Colored tiles made from recycled glass for decorative purposes.', NULL, 0, 'square meters'),
('Optical Lenses/Devices', 'Component', 'Recycled', 'Lenses and other optical components fabricated from high-purity recycled glass.', NULL, 0, 'pieces'),

-- Processed Cellulose Products
('Thin Writing/Wrapping Paper', 'Processed Material', 'Recycled', 'General-purpose paper sheets for communication and packaging.', NULL, 0, 'kilograms'),
('Thick Cardboard Panels', 'Component', 'Recycled', 'Rigid panels made from recycled cardboard for construction and packaging.', NULL, 0, 'kilograms'),
('Thick Yarn/Ropes', 'Processed Material', 'Recycled', 'Strong yarn and ropes spun from recycled textile fibers.', NULL, 0, 'kilograms'),
('Fine Threads', 'Processed Material', 'Recycled', 'Fine threads suitable for weaving into new fabrics.', NULL, 0, 'kilograms'),
('Woven Sheets/Filter Textiles', 'Component', 'Recycled', 'Woven fabrics for use as bedding, partitions, or filters.', NULL, 0, 'square meters'),
('Thick Felt for Wall/Vehicle Insulation', 'Processed Material', 'Recycled', 'Dense, nonwoven felt for acoustic and thermal insulation.', NULL, 0, 'square meters'),
('Bio-Composite Panels/Blocks', 'Component', 'Recycled', 'Durable building panels made from a cellulose-sulfur composite.', NULL, 0, 'pieces'),
('Porous Biochar', 'Processed Material', 'Recycled', 'Carbon-rich biochar from pyrolysis, used for filtration and soil amendment.', NULL, 0, 'kilograms'),

-- Processed Plastic & Foam Products
('Rigid insulation panels with protective finish', 'Component', 'Recycled', 'Finished insulation panels made from recycled foam.', NULL, 0, 'square meters'),
('Lightweight composite blocks/panels', 'Component', 'Recycled', 'Lightweight construction blocks made from a foam-regolith composite.', NULL, 0, 'units'),
('Protective packaging pieces', 'Component', 'Recycled', 'Molded inserts and pieces for protecting sensitive equipment.', NULL, 0, 'units'),
('Pyrolysis oil (bio-oil)', 'Processed Material', 'Recycled', 'A synthetic crude oil produced from the pyrolysis of plastic and organic waste.', NULL, 0, 'Liters'),
('Molded plastic parts', 'Component', 'Recycled', 'Generic plastic parts and housings re-molded from waste plastic.', NULL, 0, 'units'),
('3D Printing Filament', 'Processed Material', 'Recycled', 'Filament for 3D printers, produced from various recycled plastics like PET and HDPE.', NULL, 15.5, 'kg'),

-- Processed Metal Products
('Pure copper wire and conductors', 'Component', 'Recycled', 'High-purity copper wire of various gauges drawn from recycled scrap metal.', NULL, 0, 'kg'),
('Aluminum rods, sheets, frames, plates', 'Component', 'Recycled', 'Structural and plate aluminum produced from recycled scrap for construction.', NULL, 0, 'units'),
('Steel/iron rods, anchor bases, fasteners', 'Component', 'Recycled', 'Various heavy-duty components forged or machined from recycled steel.', NULL, 0, 'units'),
('Metal powder or wire for additive manufacturing', 'Processed Material', 'Recycled', 'Fine metal powder or spooled wire for use in 3D printers.', NULL, 0, 'kg');