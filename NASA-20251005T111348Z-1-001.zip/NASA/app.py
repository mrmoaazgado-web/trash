from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError
from sqlalchemy.sql import func
import random

# --- إعداد السيرفر ---
app = Flask(__name__)
CORS(app)

# --- إعدادات الاتصال بقاعدة البيانات ---
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:hany67334@localhost/nasa_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# --- تعريف نماذج قاعدة البيانات ---
class Inventory(db.Model):
    __tablename__ = 'inventory'
    inventory_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False, unique=True)
    type = db.Column(db.String(255))
    source = db.Column(db.String(255))
    description = db.Column(db.Text)
    details = db.Column(db.JSON)
    quantity = db.Column(db.Numeric(10, 2), nullable=False, default=0.00)
    unit = db.Column(db.String(20), nullable=False)
    last_updated = db.Column(db.TIMESTAMP, server_default=db.func.now(), onupdate=db.func.now())

class Processes(db.Model):
    __tablename__ = 'processes'
    process_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    process_name = db.Column(db.String(255), nullable=False, unique=True)
    process_type = db.Column(db.String(100))
    description = db.Column(db.Text)
    details = db.Column(db.JSON)
    inputs = db.Column(db.JSON)
    outputs = db.Column(db.JSON)

# --- نقاط النهاية (API Endpoints) ---

@app.route('/api/inventory', methods=['GET', 'POST'])
def handle_inventory():
    if request.method == 'POST':
        return add_inventory_item()
    
    try:
        all_items = Inventory.query.all()
        inventory_list = [{
            'id': item.inventory_id, 'name': item.name, 'type': item.type, 
            'source': item.source, 'description': item.description, 'details': item.details, 
            'quantity': float(item.quantity), 'unit': item.unit,
            'last_updated': item.last_updated.isoformat() if item.last_updated else None
        } for item in all_items]
        return jsonify(inventory_list)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/inventory/<int:item_id>', methods=['DELETE'])
def delete_inventory_item(item_id):
    try:
        item_to_delete = Inventory.query.get(item_id)
        if not item_to_delete: return jsonify({"error": "Item not found"}), 404
        db.session.delete(item_to_delete)
        db.session.commit()
        return jsonify({"message": "Item deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to delete item"}), 500

def add_inventory_item():
    try:
        data = request.get_json()
        name = data.get('name')
        if not name or data.get('quantity') is None or not data.get('unit'): return jsonify({"error": "Missing required fields"}), 400
        if Inventory.query.filter_by(name=name).first(): return jsonify({"error": "Item name already exists"}), 409
        new_item = Inventory(name=name, quantity=data.get('quantity'), unit=data.get('unit'), type=data.get('type', ''), source=data.get('source', ''), description=data.get('description', ''), details=data.get('details', {}))
        db.session.add(new_item)
        db.session.commit()
        return jsonify({'id': new_item.inventory_id, 'name': new_item.name, 'type': new_item.type, 'source': new_item.source, 'description': new_item.description, 'details': new_item.details, 'quantity': float(new_item.quantity), 'unit': new_item.unit, 'last_updated': new_item.last_updated.isoformat() if new_item.last_updated else None}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to add item"}), 500

@app.route('/api/processes', methods=['GET'])
def get_processes():
    try:
        all_processes = Processes.query.all()
        processes_list = [{'id': proc.process_id, 'name': proc.process_name, 'type': proc.process_type, 'description': proc.description, 'details': proc.details, 'inputs': proc.inputs, 'outputs': proc.outputs} for proc in all_processes]
        return jsonify(processes_list)
    except Exception as e:
        return jsonify({"error": "Could not fetch processes"}), 500

@app.route('/api/recyclable-materials', methods=['GET'])
def get_recyclable_materials():
    try:
        # ✨ هذا هو التعديل المطلوب: جلب المواد من نوع 'Recycling' و 'Waste' ✨
        recyclable_items = Inventory.query.filter(Inventory.type.in_(['Recycling', 'Waste'])).all()
        
        materials_list = [{'id': item.inventory_id, 'name': item.name, 'quantity': float(item.quantity), 'unit': item.unit} for item in recyclable_items]
        return jsonify(materials_list)
    except Exception as e:
        return jsonify({"error": "Could not fetch recyclable materials"}), 500

@app.route('/api/recycling-processes', methods=['POST'])
def get_recycling_processes():
    try:
        data = request.get_json()
        selected_materials = data.get('materials', [])
        if not selected_materials: return jsonify([])
        all_processes = Processes.query.all()
        potential_outputs = []
        for process in all_processes:
            if not process.inputs: continue
            if any(item in process.inputs for item in selected_materials):
                if process.outputs:
                    for output_name in process.outputs:
                        potential_outputs.append({"icon": "♻️", "title": output_name, "description": f"Can be produced via '{process.process_name}'.", "category": "Recycled Product", "producing_process_name": process.process_name, "recovery": f"{random.randint(75, 95)}%", "energy": f"{random.randint(10, 50)} kWh/kg", "time": f"{random.randint(1, 4)} hr", "quality": random.choice(["High", "Medium", "Utility"])})
        return jsonify(list({v['title']:v for v in potential_outputs}.values()))
    except Exception as e:
        return jsonify({"error": "Failed to analyze recycling potential"}), 500

@app.route('/api/processes-for-item/<string:item_name>', methods=['GET'])
def get_processes_for_item(item_name):
    try:
        matching_processes = Processes.query.filter(func.json_contains(Processes.inputs, f'"{item_name}"')).all()
        processes_list = [{'id': proc.process_id, 'name': proc.process_name, 'type': proc.process_type, 'description': proc.description, 'outputs': proc.outputs} for proc in matching_processes]
        return jsonify(processes_list)
    except Exception as e:
        return jsonify({"error": "Could not fetch processes for the item"}), 500

@app.route('/api/recycling-recommendation', methods=['POST'])
def get_recycling_recommendation():
    try:
        data = request.get_json()
        output_names = data.get('outputs', [])
        if not output_names: return jsonify({"error": "No output products provided"}), 400
        inventory_items = Inventory.query.filter(Inventory.name.in_(output_names)).all()
        stock_levels = {item.name: float(item.quantity) for item in inventory_items}
        recommendation = None
        min_quantity = float('inf')
        for name in output_names:
            quantity = stock_levels.get(name, 0)
            if quantity < min_quantity:
                min_quantity = quantity
                recommendation = name
        return jsonify({"recommendation": recommendation})
    except Exception as e:
        return jsonify({"error": "Could not fetch recommendation"}), 500

@app.route('/api/inventory/low-stock', methods=['GET'])
def get_low_stock_items():
    try:
        LOW_STOCK_THRESHOLD = 50 
        low_stock_items = Inventory.query.filter(Inventory.quantity < LOW_STOCK_THRESHOLD).all()
        inventory_list = [{'id': item.inventory_id, 'name': item.name, 'type': item.type, 'source': item.source, 'description': item.description, 'details': item.details, 'quantity': float(item.quantity), 'unit': item.unit} for item in low_stock_items]
        return jsonify(inventory_list)
    except Exception as e:
        return jsonify({"error": "Could not fetch low stock items"}), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)